
public interface ScreenTreeFeedback {

	public void receiveFeedback (byte code);
	
}
