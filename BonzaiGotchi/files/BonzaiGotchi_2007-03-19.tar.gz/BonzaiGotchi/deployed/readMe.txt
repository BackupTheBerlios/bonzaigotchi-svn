Install
 simply copy .jad and .jar file to mobile

Confirmed Devices:
 MDA Pro
 Siemens S65

Working Buttons:
 - Resume [if Tree saved]
 - New Tree

 TreeMenu
 - Edit
 - Water
 - Change Pot
 EditMenu
 - Back
 - Cut Branch
